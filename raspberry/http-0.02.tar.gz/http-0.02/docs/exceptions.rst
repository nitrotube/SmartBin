.. _exceptions:

Exceptions:
===========

.. module:: http.exception

Synopsys
--------

Interface
---------

:class:`HTTException` instances have the following methods:

.. autoclass:: HTTPException()
   :members:
   :undoc-members:
